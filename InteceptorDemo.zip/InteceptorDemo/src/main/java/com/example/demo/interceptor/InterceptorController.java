package com.example.demo.interceptor;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * <p>
 * </p>
 *
 * @author jiadianxia001
 * @since 2019/7/25
 */
@RestController
@RequestMapping("test")
public class InterceptorController {

    @GetMapping("name")
    public void test(String name) {
        System.out.println("controller" + name);
    }

}
