### springboot自定义的拦截器
- 拦截器步骤：
- 1.创建自己的拦截器类并实现 HandlerInterceptor接口。 @Component
- 2.创建一个Java类继承WebMvcConfigurerAdapter，并重写 addInterceptors 方法。@Configuration
- 3.实例化自定义的拦截器（如果interceptor中不注入redis或其他项目可以直接new）
- 4.将拦截器对像手动添加到拦截器链中（在addInterceptors方法中添加）

### 拦截器的具体方法执行时间节点
- preHandle()方法：进入controller层之前拦截请求.
- postHandle()方法：处理请求完成后视图渲染之前的处理操作 请求之后，控制器中抛出了异常的话就不会执行。\
- afterCompletion() 方法：视图渲染之后的操作，请求之后调用，不管抛不抛出异常都会被调用.参数中异常如果被异常处理器调用的话就不会传入到参数中。(视图渲染之后的资源清理)
